var str = "Hello, Playground!"

let pi = 3.1415926

var num: Int = -23
print (Int.max)
print (Int.min)

var age = 21
var height = 5.8

var x = 34 + 52.9
var intX = Int(x)

// Boolean - True or False
var decide: Bool = false

var numberInString = "2357"
var numberInInteger: Int? = Int (numberInString)

if (numberInInteger != nil) {
    print (numberInInteger!)
}

// optional binding

if let convertedNum = Int (numberInString) {
    print (convertedNum)
} else {
    print ("No Value")
}
